#include <zephyr/kernel.h>             // Funções básicas do Zephyr (ex: k_msleep, k_thread, etc.)
#include <zephyr/device.h>             // API para obter e utilizar dispositivos do sistema
#include <zephyr/drivers/gpio.h>       // API para controle de pinos de entrada/saída (GPIO)
#include <zephyr/drivers/uart.h>
#include <zephyr/sys/printk.h>
#include <pwm_z42.h>                // Biblioteca personalizada com funções de controle do TPM (Timer/PWM Module)

// Definir LEDS
#define LEDGREEN_NODE DT_ALIAS(led0)
#define LEDBLUE_NODE DT_ALIAS(led1)
#define LEDRED_NODE DT_ALIAS(led2)

#if DT_NODE_HAS_STATUS(LEDGREEN_NODE, okay)
    static const struct gpio_dt_spec ledgreen = GPIO_DT_SPEC_GET(LEDGREEN_NODE, gpios);
#else
    #error "Unsupported board: led0 devicetree alias is not defined"
#endif

#if DT_NODE_HAS_STATUS(LEDBLUE_NODE, okay)
    static const struct gpio_dt_spec ledblue = GPIO_DT_SPEC_GET(LEDBLUE_NODE, gpios);
#else
    #error "Unsupported board: led1 devicetree alias is not defined"
#endif


#if DT_NODE_HAS_STATUS(LEDRED_NODE, okay)
    static const struct gpio_dt_spec ledred = GPIO_DT_SPEC_GET(LEDRED_NODE, gpios);
#else
    #error "Unsupported board: led2 devicetree alias is not defined"
#endif


// Definir UART
#define UART0_NODE DT_NODELABEL(uart0)



// Define o valor do registrador MOD do TPM para configurar o período do PWM
#define TPM_MODULE 1000         // Define a frequência do PWM fpwm = (TPM_CLK / (TPM_MODULE * PS))
// Valores de duty cycle correspondentes a diferentes larguras de pulso
uint16_t duty_50  = TPM_MODULE/2;       // 50% de duty cycle (meio brilho)
uint16_t duty_10  = TPM_MODULE/10;
uint16_t duty_25  = TPM_MODULE/4;
uint16_t duty_20  = TPM_MODULE/5;

int main(void)
{

    int retred;
	int retgreen;
    int retblue;

     // Verifica se o device está pronto
    if (!gpio_is_ready_dt(&ledred)) {
        printk("Error: LED RED device %s is not ready\n", ledred.port->name);
        return;
    }

    if (!gpio_is_ready_dt(&ledblue)) {
        printk("Error: LED BLUE device %s is not ready\n", ledblue.port->name);
        return;
    }

	if (!gpio_is_ready_dt(&ledgreen)) {
        printk("Error: LED GREEN device %s is not ready\n", ledgreen.port->name);
        return;
    }


    // Configura o pino como saída
    retred = gpio_pin_configure_dt(&ledred, GPIO_OUTPUT_ACTIVE);
    if (retred < 0) {
        printk("Error %d: failed to configure LED RED pin\n", retred);
        return;
    }
    retblue = gpio_pin_configure_dt(&ledblue, GPIO_OUTPUT_ACTIVE);
	if (retblue < 0) {
        printk("Error %d: failed to configure LED BLUE pin\n", retblue);
        return;
    }
	retgreen = gpio_pin_configure_dt(&ledgreen, GPIO_OUTPUT_ACTIVE);
	if (retgreen < 0) {
        printk("Error %d: failed to configure LED GREEN pin\n", retgreen);
        return;
    }

    // Inicializar UART
    const struct device *uart0 = DEVICE_DT_GET(UART0_NODE);
    if (!device_is_ready(uart0)) {
        printk("UART0 não está pronta!\n");
        return;
    }


    // Inicializa o módulo TPM2 com:
    // - base do TPMx
    // - fonte de clock PLL/FLL (TPM_CLK)
    // - valor do registrador MOD
    // - tipo de clock (TPM_CLK)
    // - prescaler de 1 a 128 (PS)
    // - modo de operação EDGE_PWM

    pwm_tpm_Init(TPM2, TPM_PLLFLL, TPM_MODULE, TPM_CLK, PS_128, EDGE_PWM);

    // Inicializa o canal 0 do TPM2 para gerar sinal PWM na porta GPIOB_18
    // - modo TPM_PWM_H (nível alto durante o pulso)
    pwm_tpm_Ch_Init(TPM2, 1, TPM_PWM_H, GPIOB, ledgreen.pin);
    pwm_tpm_Ch_Init(TPM2, 0, TPM_PWM_H, GPIOB, ledred.pin);

    // Define o valor do duty cycle: nesse caso, duty_100 (LED quase desligado)
    pwm_tpm_CnV(TPM2, 1, duty_10);
    pwm_tpm_CnV(TPM2, 0, duty_50);

    // Zera o led blue
    gpio_pin_set_dt(&ledblue, 0);


    uint8_t receive_int() {

        uint8_t v;
        char inc_msg[5];
        uint8_t buf_indx = 0;

        while (1) {
            if (uart_poll_in(uart0, &v) == 0){
                if (v == '\r') {
                    break;
                } else {
                    inc_msg[buf_indx++] = v; 
                }
            }
        }

        inc_msg[buf_indx] = '\0';
        uint8_t result = atoi(inc_msg);
        return result;

    }

    const int r_duty = 80;
    const int g_duty = 180;

    // Loop infinito
    for (;;)
    {
        // const char msg1[] = "Insira o valor Red (0 - 255): ";
        // const char msg2[] = "Insira o valor Green (0 - 255): ";
        
        // for (int i = 0; i < sizeof(msg1) - 1; i++) {
        //     uart_poll_out(uart0, msg1[i]);
        // }

        // uint8_t r = receive_int();
        // printk("%u\n", (unsigned int)r);
        // pwm_tpm_CnV(TPM2, 1, (( TPM_MODULE * (255- r))/255) );

        // for (int i = 0; i < sizeof(msg2) - 1; i++) {
        //     uart_poll_out(uart0, msg2[i]);
        // }

        // uint8_t g = receive_int();
        // printk("%u\n", (unsigned int)g);
        // pwm_tpm_CnV(TPM2, 0, (( TPM_MODULE * (255 -g))/255) );

        const char msg1[] = "Insira o valor do brilho (0 - 100): ";

        for (int i = 0; i < sizeof(msg1) - 1; i++) {
            uart_poll_out(uart0, msg1[i]);
        }

        uint8_t brilho = receive_int();
        printk("%u\n", (unsigned int)brilho);
        pwm_tpm_CnV(TPM2, 1, (( TPM_MODULE * (100 - brilho))/100) );
        pwm_tpm_CnV(TPM2, 0, ( (TPM_MODULE * (100 - (brilho/2)))/100 ));

    }

    return 0;
}